import java.util.Scanner;
class Main {
  public static void main(String[] args) {
     Scanner sv = new Scanner(System.in);
    System.out.println("Enter the marks of biology:");
    int bio = sv.nextInt();
    System.out.println("Marks of Biology is:"+bio);
     System.out.println("Enter the marks of chemistry:");
    int chem = sv.nextInt();
    System.out.println("Marks of Chemistry is:"+chem);
    System.out.println("Enter the marks of Mathematics:");
    int math = sv.nextInt();
    System.out.println("Marks of Maths is:"+math);
     System.out.println("Enter the marks of English:");
    int eng = sv.nextInt();
    System.out.println("Marks of English is:"+eng);
    System.out.println("obtained Marks are:");
    int obtained=bio+chem+math+eng;
    System.out.println(obtained); 
    int total=400;
    System.out.println("Total marks are:   "+total);
    System.out.println("Average marks are:");
    int average=(obtained*100)/total;
    System.out.println(average);
    
    
  }
}